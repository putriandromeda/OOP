package app.meetup.PenerapanInheritance.Java;

import app.meetup.R;

public class RegisterActivity extends BaseActivity {

    @Override protected int getLayout() {
        return R.layout.activity_register;
    }
    @Override protected void onMain() {

    }
}
