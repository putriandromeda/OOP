package app.meetup.PenerapanInheritance.Kotlin

import app.meetup.R

class LoginActivityKotlin : BaseActivityKotlin() {
    override fun getLayout(): Int {
        return R.layout.activity_login_kotlin
    }

    override fun onMain() {

    }

}
